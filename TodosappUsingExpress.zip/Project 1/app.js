const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');
const expressValidator = require('express-validator');
const port = 3000;

//init app
const app = express();

const MongoClient = require('mongodb').MongoClient;
const ObjectID = require('mongodB').ObjectID;
const url = 'mongodb://localhost:27017/todosapp';

//middleware bodyparser
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended:false}));
app.use(express.static(path.join(__dirname,'public')));
app.use(expressValidator());
//view setup
app.set('views',path.join(__dirname,'views'));
app.set('view engine','ejs');

//get page
app.get('/', (req,res,next) =>{
    Todos.find({}).toArray((err,todos) =>{
        if(err){
            return console.log(err);
        }
        console.log(todos);
        res.render('index',{
            todos : todos
        });
    });
})

app.post('/todo/add', (req,res,next) => {
   // console.log('submitted');
   //create todos
   const todo = {
       text : req.body.text,
       body : req.body.body
   }

   //insert todo
   Todos.insert(todo,(err,result) => {
        if(err){
            return console.log(err);
        }
        console.log('Todo Added...');
        res.redirect('/');
   });
});

app.delete('/todo/delete/:id', (req,res,next) => {
  const query = {_id : ObjectID(req.params.id)}
  Todos.deleteOne(query,(err,response)=>{
    if(err){
        return console.log(err);
    }
    res.send(200);
  });
});

app.get('/todo/edit/:id', (req,res,next) =>{
    const query = {_id : ObjectID(req.params.id)}
    Todos.find(query).next((err,todo) =>{
        if(err){
            return console.log(err);
        }
        res.render('edit',{
            todo : todo
        });
    });
})


app.post('/todo/edit/:id', (req,res,next) => {
   const query = {_id : ObjectID(req.params.id)}
   const todo = {
       text : req.body.text,
       body : req.body.body
   }


   //update todo
   Todos.updateOne(query,{$set:todo},(err,result) => {
       
        if(err){
            return console.log(err);
        }
        
        console.log('Todo updated...');
        res.redirect('/');
   });
});


//connect mongodb


MongoClient.connect(url,(err,database) =>{
    console.log('mongo db connected..');
    if(err) throw err;

    db = database;
    Todos = db.collection('todos');

    app.listen(port, () => {
    console.log('server running on port'+port);
});
});

